function Get-FastestGitUrl {
    # --- Parameters ---
    param(
        [int]$TimeoutSeconds = 5,
        [switch]$FullClone = $false
    )

    # Add your repository URLs here.
    $RepositoryUrls = @(
        "https://gh-proxy.com/https://github.com/ScoopInstaller/Main",
        "https://hk.gh-proxy.com/https://github.com/ScoopInstaller/Main",
        "https://cdn.gh-proxy.com/https://github.com/ScoopInstaller/Main",
        "https://ghproxy.home.sdhsparke.com/https://github.com/ScoopInstaller/Main"
    )

    # --- Script Body ---
    
    # Check if 'git' command exists
    $gitExists = [bool](Get-Command git -ErrorAction SilentlyContinue)
    
    # === BRANCH 1: GIT EXISTS (Keep Parallel Mode for Speed) ===
    if ($gitExists) {
        Write-Host "Git detected. Starting PARALLEL Git Clone Speed Test..." -ForegroundColor Yellow
        Write-Host "Timeout set to $TimeoutSeconds seconds." -ForegroundColor Yellow

        $jobs = @()
        $jobUrlMap = @{}
        $tempDirs = @{}

        # Start jobs in parallel
        foreach ($url in $RepositoryUrls) {
            $tempDir = Join-Path $env:TEMP ("git-test-" + [System.Guid]::NewGuid().ToString().Substring(0, 8))
            $scriptBlock = {
                param($url, $tempDir, $isFullClone)
                # Force TLS 1.2 in background job
                [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12
                
                $success = $false
                $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
                
                $cloneArgs = if ($isFullClone) { @("clone", "--quiet", $url, $tempDir) } else { @("clone", "--depth", "1", "--quiet", $url, $tempDir) }
                $errFile = Join-Path $env:TEMP "git-err-$($PID).txt"
                
                # Execute git command
                git @cloneArgs 2> $errFile
                if ($LASTEXITCODE -eq 0) { $success = $true }
                
                $stopwatch.Stop()
                if (Test-Path $errFile) { Remove-Item $errFile -ErrorAction SilentlyContinue }
                
                return [PSCustomObject]@{ Url = $url; Success = $success; TimeInSeconds = $stopwatch.Elapsed.TotalSeconds; TempDir = $tempDir }
            }
            $job = Start-Job -ScriptBlock $scriptBlock -ArgumentList @($url, $tempDir, $FullClone.IsPresent)
            $jobs += $job
            $jobUrlMap[$job.Id] = $url
            $tempDirs[$job.Id] = $tempDir
        }

        # Wait for jobs to complete or timeout
        Wait-Job -Job $jobs -Timeout $TimeoutSeconds | Out-Null
        
        $results = @()
        foreach ($job in $jobs) {
            # Fix: Stop the job if it's still running (Timed out) to prevent Remove-Job errors
            if ($job.State -ne 'Completed') { 
                Stop-Job -Job $job -ErrorAction SilentlyContinue
            }
            
            # Receive data if completed
            if ($job.State -eq 'Completed' -or $job.HasMoreData) { 
                $results += Receive-Job -Job $job -ErrorAction SilentlyContinue
            }
            
            # Remove job using Force to ensure cleanup
            Remove-Job -Job $job -Force -ErrorAction SilentlyContinue
        }
        
        # Cleanup temp directories
        foreach ($res in $results) { 
            if ($res.TempDir -and (Test-Path $res.TempDir)) { 
                Remove-Item -Path $res.TempDir -Recurse -Force -ErrorAction SilentlyContinue 
            } 
        }
        
        # Select the best URL
        $bestUrl = $results | Where-Object { $_.Success } | Sort-Object TimeInSeconds | Select-Object -First 1
    }
    
    # === BRANCH 2: GIT MISSING (Use Serial TCP Check in Main Thread) ===
    else {
        Write-Host "Git not found. Running SERIAL connectivity test in current session..." -ForegroundColor Magenta
        Write-Host "Testing URLs one by one to ensure accuracy..." -ForegroundColor Gray
        
        $results = @()

        foreach ($url in $RepositoryUrls) {
            $uri = [System.Uri]$url
            $hostName = $uri.Host
            $port = 443
            $success = $false
            $elapsed = [double]::MaxValue
            
            Write-Host -NoNewline " -> Checking $hostName ... "

            try {
                $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
                
                # Create TCP Client
                $client = New-Object System.Net.Sockets.TcpClient
                
                # Use BeginConnect to support timeout
                $asyncResult = $client.BeginConnect($hostName, $port, $null, $null)
                
                # Wait 2 seconds max per URL (Fast fail)
                $waitSuccess = $asyncResult.AsyncWaitHandle.WaitOne(2000, $false)
                
                if ($waitSuccess) {
                    try {
                        $client.EndConnect($asyncResult)
                        if ($client.Connected) {
                            $stopwatch.Stop()
                            $elapsed = $stopwatch.Elapsed.TotalSeconds
                            $success = $true
                            Write-Host "OK ($($elapsed.ToString('N3'))s)" -ForegroundColor Green
                        }
                    } catch {
                        Write-Host "Refused" -ForegroundColor Red
                    }
                } else {
                    Write-Host "Timeout" -ForegroundColor Red
                }
                $client.Close()
                $client.Dispose()
            }
            catch {
                Write-Host "Error" -ForegroundColor Red
            }
            
            $results += [PSCustomObject]@{ Url = $url; Success = $success; TimeInSeconds = $elapsed }
        }
        
        $bestUrl = $results | Where-Object { $_.Success } | Sort-Object TimeInSeconds | Select-Object -First 1
    }

    # === FINAL OUTPUT ===
    if ($bestUrl) {
        Write-Host "`nRecommended Fastest URL:" -ForegroundColor Cyan
        Write-Host " $($bestUrl.Url)" -ForegroundColor Green
        
        $proxyPrefix = $bestUrl.Url -replace "/https://github.com/ScoopInstaller/Main$", ""
        return $proxyPrefix
    } else {
        Write-Host "`n[WARNING] All connections failed. Using default." -ForegroundColor Red
        return $null
    }
}
