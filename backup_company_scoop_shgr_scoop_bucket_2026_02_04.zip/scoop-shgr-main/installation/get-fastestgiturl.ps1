function Get-FastestGitUrl {
    # --- Parameters ---
    param(
        [int]$TimeoutSeconds = 20, # Increased default timeout for serial execution
        [switch]$FullClone = $false
    )

    # Add your repository URLs here.
    $RepositoryUrls = @(
        "https://gh-proxy.com/https://github.com/ScoopInstaller/Main",
        "https://hk.gh-proxy.com/https://github.com/ScoopInstaller/Main",
        "https://cdn.gh-proxy.com/https://github.com/ScoopInstaller/Main",
        "https://ghproxy.home.sdhsparke.com/https://github.com/ScoopInstaller/Main"
    )

    # --- Script Body ---
    
    # Check if 'git' command exists
    $gitExists = [bool](Get-Command git -ErrorAction SilentlyContinue)
    
    $results = @()

    # === BRANCH 1: GIT EXISTS (Serial Git Clone) ===
    # We use Serial execution in the Main Thread to avoid network isolation issues in Background Jobs
    if ($gitExists) {
        Write-Host "Git detected. Starting SERIAL Git Clone Speed Test (Main Thread)..." -ForegroundColor Yellow
        Write-Host "Testing URLs one by one for maximum reliability..." -ForegroundColor Gray

        foreach ($url in $RepositoryUrls) {
            $tempDir = Join-Path $env:TEMP ("git-test-" + [System.Guid]::NewGuid().ToString().Substring(0, 8))
            $success = $false
            $elapsed = [double]::MaxValue
            
            # Extract hostname for display
            $displayUrl = $url
            if ($url.Length -gt 50) { $displayUrl = $url.Substring(0, 47) + "..." }
            Write-Host -NoNewline " -> Checking $displayUrl ... "

            try {
                $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
                
                # Prepare Git args
                $cloneArgs = if ($FullClone) { @("clone", "--quiet", $url, $tempDir) } else { @("clone", "--depth", "1", "--quiet", $url, $tempDir) }
                
                # Redirect stderr to file to keep console clean
                $errFile = Join-Path $env:TEMP "git-err-$($PID).txt"
                
                # Execute Git (Synchronously)
                git @cloneArgs 2> $errFile
                
                $stopwatch.Stop()
                
                if ($LASTEXITCODE -eq 0) {
                    $success = $true
                    $elapsed = $stopwatch.Elapsed.TotalSeconds
                    Write-Host "OK ($($elapsed.ToString('N2'))s)" -ForegroundColor Green
                } else {
                    Write-Host "Failed" -ForegroundColor Red
                }

                # Cleanup
                if (Test-Path $tempDir) { Remove-Item -Path $tempDir -Recurse -Force -ErrorAction SilentlyContinue }
                if (Test-Path $errFile) { Remove-Item $errFile -ErrorAction SilentlyContinue }

            }
            catch {
                Write-Host "Error" -ForegroundColor Red
            }
            
            $results += [PSCustomObject]@{ Url = $url; Success = $success; TimeInSeconds = $elapsed }
        }
    }
    
    # === BRANCH 2: GIT MISSING (Serial TCP Check) ===
    else {
        Write-Host "Git not found. Running SERIAL connectivity test (TCP Port 443)..." -ForegroundColor Magenta
        
        foreach ($url in $RepositoryUrls) {
            $uri = [System.Uri]$url
            $hostName = $uri.Host
            $port = 443
            $success = $false
            $elapsed = [double]::MaxValue
            
            Write-Host -NoNewline " -> Checking $hostName ... "

            try {
                $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
                $client = New-Object System.Net.Sockets.TcpClient
                
                # Use BeginConnect for timeout support
                $asyncResult = $client.BeginConnect($hostName, $port, $null, $null)
                $waitSuccess = $asyncResult.AsyncWaitHandle.WaitOne(3000, $false) # 3s timeout per host
                
                if ($waitSuccess) {
                    try {
                        $client.EndConnect($asyncResult)
                        if ($client.Connected) {
                            $stopwatch.Stop()
                            $elapsed = $stopwatch.Elapsed.TotalSeconds
                            $success = $true
                            Write-Host "OK ($($elapsed.ToString('N3'))s)" -ForegroundColor Green
                        }
                    } catch { Write-Host "Refused" -ForegroundColor Red }
                } else {
                    Write-Host "Timeout" -ForegroundColor Red
                }
                $client.Close()
                $client.Dispose()
            }
            catch { Write-Host "Error" -ForegroundColor Red }
            
            $results += [PSCustomObject]@{ Url = $url; Success = $success; TimeInSeconds = $elapsed }
        }
    }

    # === FINAL OUTPUT ===
    $bestUrl = $results | Where-Object { $_.Success } | Sort-Object TimeInSeconds | Select-Object -First 1

    if ($bestUrl) {
        Write-Host "`nRecommended Fastest URL:" -ForegroundColor Cyan
        Write-Host " $($bestUrl.Url)" -ForegroundColor Green
        
        $proxyPrefix = $bestUrl.Url -replace "/https://github.com/ScoopInstaller/Main$", ""
        return $proxyPrefix
    } else {
        Write-Host "`n[WARNING] All connections failed. Using default." -ForegroundColor Red
        return $null
    }
}
