# Install Software
function Install-Software {
  $SOFTWARE_NAMES = @("scoop-cn/aria2", "scoop-cn/dark", "scoop-cn/innounp", 
  "scoop-bucket/cms6", "sparkebucket/univpn-np", "sparkebucket/xylink-np", "sparkebucket/sdriveclient-np", "scoop-cn/wecom", "scoop-cn/wechat")
  foreach ($SOFTWARE in $SOFTWARE_NAMES) {
    $SOFTWARE_CONTENT | ForEach-Object { scoop install $SOFTWARE $PSItem }
  }
  # Your original gsudo commands for system configuration.
    Write-Host "Configuring system settings..."

    Write-Host "Temporarily disabling UAC..."
    gsudo reg add HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System /v ConsentPromptBehaviorAdmin /t REG_DWORD /d 0 /f

    Write-Host "Enabling Long Paths support..."
    gsudo Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\FileSystem' -Name 'LongPathsEnabled' -Value 1

    Write-Host "Enabling Developer Mode..."
    gsudo Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\AppModelUnlock' -Name 'AllowDevelopmentWithoutDevLicense' -Value 1

    Write-Host "Ensuring Git SSL verification is enabled..."
    git config --global http.sslverify true

    Write-Host "Restoring UAC to default settings..."
    gsudo reg add HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System /v ConsentPromptBehaviorAdmin /t REG_DWORD /d 5 /f
    gsudo reg add HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System /v PromptOnSecureDesktop /t REG_DWORD /d 1 /f

    Write-Host "System configuration complete."
}

Install-Software
