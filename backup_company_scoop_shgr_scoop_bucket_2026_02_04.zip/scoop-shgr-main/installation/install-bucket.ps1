# Add available bucket.
function Install-Bucket {

    Write-Host "Adding buckets in parallel." -ForegroundColor Magenta

    Write-Host "Determining fastest Git proxy URL by running get-fastestgiturl.ps1..." -ForegroundColor Cyan
    
    $GHPROXY = $null
    try {
        # Dot-source the script to load the function.
        if (Test-Path "$PSScriptRoot\get-fastestgiturl.ps1") {
            . "$PSScriptRoot\get-fastestgiturl.ps1" -ErrorAction Stop    
            # Call the function and capture the output
            # Increase timeout to 20s because we switched to SERIAL testing for reliability
            $FastestGitUrl = Get-FastestGitUrl -TimeoutSeconds 20
            
            if (-not [string]::IsNullOrWhiteSpace($FastestGitUrl)) {
                Write-Host "Successfully found fastest URL: $FastestGitUrl" -ForegroundColor Green
                $GHPROXY = $FastestGitUrl
            }
            else {
                Write-Warning "Could not determine fastest Git URL. Falling back to default."
            }
        } else {
            Write-Warning "get-fastestgiturl.ps1 not found."
        }
    }
    catch {
        Write-Warning "Failed to load or run 'get-fastestgiturl.ps1'. Error: $_. Falling back to default."
    }

    if ([string]::IsNullOrWhiteSpace($GHPROXY)) {
        # FIXED: Use public proxy as fallback instead of unreachable internal URL
        $GHPROXY = 'https://gh-proxy.com'
        Write-Host "Using fallback URL: $GHPROXY" -ForegroundColor Yellow
    }

    # Data Consolidation: Store bucket names and URLs in a hashtable for easier management.
    $bucketsToAdd = @{
        "main"         = "$GHPROXY/https://github.com/ScoopInstaller/Main"
        "sparkebucket" = "$GHPROXY/https://github.com/sdh1986/sparkebucket"
        "scoop-cn"     = "$GHPROXY/https://github.com/duzyn/scoop-cn"
        "scoop-bucket" = "https://bucket.company.shgryl.com/shendonghu/scoop-bucket"
    }
    
    Write-Host "Checking for existing buckets to manage..."
    $initialInstalledBuckets = @()
    try {
        $initialInstalledBuckets = @(scoop bucket list | ForEach-Object {
            if ($_.PSObject.Properties.Match('Name')) {
                $_.Name
            } else {
                $_.ToString()
            }
        } | ForEach-Object { $_.Trim() } | Where-Object { $_.Length -gt 0 })
    } catch {
        Write-Warning "Could not get installed bucket list. Error: $_"
    }

    $proxiedBuckets = @("main", "scoop-cn")

    foreach ($bucketName in $proxiedBuckets) {
        if ($initialInstalledBuckets -contains $bucketName) {
            Write-Host "Removing existing proxied bucket '$bucketName' to force URL update..." -ForegroundColor Yellow
            try {
                scoop bucket rm $bucketName -ErrorAction Stop
            } catch {
                Write-Warning "Failed to remove bucket '$bucketName'. It might be in use. Error: $_"
            }
        }
    }

    Write-Host "Checking for existing buckets..."
    $installedBuckets = @()
    try {
        $installedBuckets = @(scoop bucket list | ForEach-Object {
            if ($_.PSObject.Properties.Match('Name')) {
                $_.Name
            } else {
                $_.ToString()
            }
        } | ForEach-Object { $_.Trim() } | Where-Object { $_.Length -gt 0 })
        
        if ($installedBuckets.Count -gt 0) {
            Write-Host "Found installed buckets (non-proxied): $($installedBuckets -join ', ')" -ForegroundColor Gray
        } else {
            Write-Host "No existing buckets found."
        }
    } catch {
        Write-Warning "Could not get installed bucket list. Assuming all buckets need to be added. Error: $_"
    }

    # --- Start: Parallel Execution ---
    $jobs = @()
    Write-Host "Starting parallel jobs to add buckets (single attempt)..."

    # Parallel Processing: Start a background job for each bucket.
    foreach ($bucket in $bucketsToAdd.GetEnumerator()) {
        $bucketName = $bucket.Key
        $bucketUrl = $bucket.Value
        
        if ($installedBuckets -contains $bucketName) {
            Write-Host "  -> Skipping job: $bucketName (already exists)." -ForegroundColor Gray
            continue
        }
        
        Write-Host "  -> Preparing job: Add $bucketName"

        # Start-Job runs in a new process, so we must pass parameters using -ArgumentList.
        $job = Start-Job -ScriptBlock {
            param(
                $name,
                $url
            )
            
            $success = $false

            Write-Host "  [Job] Attempting to add bucket: $name ($url)..."
            
            try {
                scoop bucket add $name $url -ErrorAction Stop

                if ($LASTEXITCODE -ne 0) {
                    Throw "Scoop/Git command failed with exit code $LASTEXITCODE."
                }

                Write-Host "  [Job] Successfully processed: $name" -ForegroundColor Green
                $success = $true

            } catch {
                $errorMessage = $_.Exception.Message.Trim()
                Write-Error "  [Job] Failed to add $name. Error: $errorMessage"
                
            }

            return $success

        } -ArgumentList $bucketName, $bucketUrl

        $jobs += $job
    }

    Write-Host "Waiting for all bucket-adding jobs to complete. This might take a few minutes..." -ForegroundColor Cyan

    # Wait & Feedback: Wait for all jobs to finish, then receive their output (success or error messages).
    $jobs | Wait-Job | Receive-Job

    Write-Host "All bucket-adding jobs have completed." -ForegroundColor Green

    # Clean up the completed jobs.
    $jobs | Remove-Job
}

# Execute the function to install buckets.
Install-Bucket

# Continue with the rest of your script.
Write-Host "Proceeding to install-software.ps1..."

. "$PSScriptRoot\install-software.ps1"
