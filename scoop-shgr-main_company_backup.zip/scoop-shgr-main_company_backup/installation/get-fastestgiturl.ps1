function Get-FastestGitUrl {
    # --- Parameters ---
    param(
        [int]$TimeoutSeconds = 30,
        [switch]$FullClone = $false
    )

    # Add your repository URLs here.
    $RepositoryUrls = @(
        "https://gh-proxy.com/https://github.com/ScoopInstaller/Main",
        "https://hk.gh-proxy.com/https://github.com/ScoopInstaller/Main",
        "https://cdn.gh-proxy.com/https://github.com/ScoopInstaller/Main",
        "https://ghproxy.home.sdhsparke.com/https://github.com/ScoopInstaller/Main"
    )

    # --- Script Body ---
    $cloneType = if ($FullClone) { "Full Clone" } else { "Depth 1 Clone" }
    Write-Host "Starting PARALLEL Git clone speed test ($cloneType)..." -ForegroundColor Yellow
    Write-Host "Timeout set to $TimeoutSeconds seconds." -ForegroundColor Yellow
    Write-Host "Running on: PowerShell $($PSVersionTable.PSVersion.Major)" -ForegroundColor DarkGray

    # Check if 'git' command exists
    if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
        Write-Host "ERROR: 'git' command not found. Please ensure Git is installed and in your PATH." -ForegroundColor Red
        return $null
    }

    $jobs = @()
    $jobUrlMap = @{}
    $tempDirs = @{}

    Write-Host "Starting all test jobs in parallel..."

    foreach ($url in $RepositoryUrls) {
        # Create a unique temp directory path for the job
        $tempDir = Join-Path $env:TEMP ("git-test-" + [System.Guid]::NewGuid().ToString().Substring(0, 8))
    
        # Define the work for the job
        $scriptBlock = {
            param($url, $tempDir, $isFullClone)

            $tempErrorFile = Join-Path $env:TEMP "git-test-error-$($PID).txt"
            $errorMessage = ""
            $success = $false
            $elapsedSeconds = [double]::MaxValue

            $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
        
            $cloneArgs = @()
            if ($isFullClone) {
                $cloneArgs = @("clone", "--quiet", $url, $tempDir)
            }
            else {
                $cloneArgs = @("clone", "--depth", "1", "--quiet", $url, $tempDir)
            }
        
            git @cloneArgs 2> $tempErrorFile
            $exitCode = $LASTEXITCODE
            $stopwatch.Stop()

            if ($exitCode -eq 0) {
                $success = $true
                $elapsedSeconds = $stopwatch.Elapsed.TotalSeconds
            }
            else {
                $success = $false
                if (Test-Path $tempErrorFile) {
                    $errorMessage = (Get-Content $tempErrorFile -Raw) -join "`n"
                }
                if ([string]::IsNullOrWhiteSpace($errorMessage)) {
                    $errorMessage = "Git clone failed. Exit code: $exitCode"
                }
            }
        
            if (Test-Path $tempErrorFile) { Remove-Item $tempErrorFile }

            return [PSCustomObject]@{
                Url           = $url
                Success       = $success
                TimeInSeconds = $elapsedSeconds
                Error         = $errorMessage
                TimedOut      = $false
                TempDir       = $tempDir
            }
        }

        $job = Start-Job -ScriptBlock $scriptBlock -ArgumentList @($url, $tempDir, $FullClone.IsPresent)
        $jobs += $job

        $jobUrlMap[$job.Id] = $url
        $tempDirs[$job.Id] = $tempDir
    }

    Write-Host "All $(@($jobs).Count) jobs started. Waiting for $TimeoutSeconds seconds..."
    Wait-Job -Job $jobs -Timeout $TimeoutSeconds | Out-Null

    $results = @()

    Write-Host "Timeout reached. Collecting results..."

    foreach ($job in $jobs) {
        $jobUrl = $jobUrlMap[$job.Id]
        $jobTempDir = $tempDirs[$job.Id]

        if ($job.State -eq 'Completed') {
            $jobResult = Receive-Job -Job $job
            $results += $jobResult
        
        }
        elseif ($job.State -eq 'Running') {
            Write-Host "  [TIMEOUT] Job for $jobUrl is still running. Stopping." -ForegroundColor Yellow
            Stop-Job -Job $job
        
            $results += [PSCustomObject]@{
                Url           = $jobUrl
                Success       = $false
                TimeInSeconds = [double]::MaxValue
                Error         = "Operation timed out after $TimeoutSeconds seconds."
                TimedOut      = $true
                TempDir       = $jobTempDir
            }
        
        }
        elseif ($job.State -eq 'Failed') {
            $errorMessage = $job.JobStateInfo.Reason.Message
            Write-Host "  [FAILED] Job for $jobUrl failed: $errorMessage" -ForegroundColor Red
        
            $results += [PSCustomObject]@{
                Url           = $jobUrl
                Success       = $false
                TimeInSeconds = [double]::MaxValue
                Error         = "Job failed: $errorMessage"
                TimedOut      = $false
                TempDir       = $jobTempDir
            }
        }
        Remove-Job -Job $job
    }

    Write-Host "Cleaning up temporary directories..."
    foreach ($res in $results) {
        if ($res.TempDir -and (Test-Path $res.TempDir)) {
            Remove-Item -Path $res.TempDir -Recurse -Force -ErrorAction SilentlyContinue
        }
    }

    Write-Host "`n--- Test Results (Fastest to Slowest) ---" -ForegroundColor Yellow
    $sortedResults = $results | Sort-Object TimeInSeconds

    $sortedResults | Format-Table Url, Success, TimedOut, @{Name = "Time (Seconds)"; Expression = { "{0:N2}" -f $_.TimeInSeconds } }, Error -AutoSize | Out-Host

    $bestUrl = $sortedResults | Where-Object { $_.Success -eq $true } | Select-Object -First 1

    if ($bestUrl) {
        Write-Host "`n"
        Write-Host "--------------------------------------------------" -ForegroundColor Cyan
        Write-Host " Recommended Fastest URL (finished under $TimeoutSeconds s):" -ForegroundColor Cyan
        Write-Host " $($bestUrl.Url)" -ForegroundColor Cyan
        Write-Host " Time: $($bestUrl.TimeInSeconds.ToString('N2')) seconds" -ForegroundColor Cyan
        Write-Host "--------------------------------------------------" -ForegroundColor Cyan
        
        $proxyPrefix = $bestUrl.Url -replace "/https://github.com/ScoopInstaller/Main$", ""
        
        Write-Host " -> Extracted proxy prefix for use: $proxyPrefix" -ForegroundColor DarkGray
        
        return $proxyPrefix
    }
    else {
        Write-Host "`n[WARNING] No clones completed successfully within the $TimeoutSeconds second timeout." -ForegroundColor Yellow
        
        return $null
    }
}