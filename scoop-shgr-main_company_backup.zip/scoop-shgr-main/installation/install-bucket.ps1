# Add available bucket.
function Install-Bucket {
  $BUCKET_FILES = @("shgr", "grsh", "scoop-cn")
  foreach ($BUCKET in $BUCKET_FILES) {
    $BUCKET_CONTENT = Get-Content "$PSScriptRoot\src\$BUCKET.txt"
    $BUCKET_CONTENT | ForEach-Object { scoop bucket rm $BUCKET $PSItem }
    $BUCKET_CONTENT | ForEach-Object { scoop bucket add $BUCKET $PSItem }
  }
  gsudo Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\FileSystem' -Name 'LongPathsEnabled' -Value 1
  gsudo Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\AppModelUnlock' -Name 'AllowDevelopmentWithoutDevLicense' -Value 1
#  git config --global http.sslverify true
  gsudo reg add HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System /v ConsentPromptBehaviorAdmin /t REG_DWORD /d 5 /f
}

Install-Bucket
