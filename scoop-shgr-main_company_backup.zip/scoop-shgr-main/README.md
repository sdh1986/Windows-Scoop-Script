# 一键部署Scoop

说明：本脚本用来一键安装scoop及添加相应的源和bucket

系统要求：请使用Powershell 5.1 或更高版本运行,运行Powershell并使用以下命令检测是否符合要求
```
$PSVersionTable
```
使用方法：
```
Set-ExecutionPolicy RemoteSigned -Scope CurrentUser
irm https://bucket.company.shgryl.com/shendonghu/Install-Software/-/raw/master/Scoop-Installer.ps1 | iex ; Exit
```
