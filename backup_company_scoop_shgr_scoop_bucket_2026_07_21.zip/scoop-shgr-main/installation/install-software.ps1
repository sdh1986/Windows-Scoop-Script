# Install Software
function Install-Software {
  $SOFTWARE_NAMES = @("scoop-cn/aria2", "scoop-cn/dark", "scoop-cn/innounp", 
  "scoop-bucket/cms6", "sparkebucket/univpn-np", "sparkebucket/xylink-np", 
  "sparkebucket/sinopharmwps365-np", "sparkebucket/sdriveclient-np", 
  "scoop-cn/wecom", "scoop-cn/wechat")

  $installed = @()
  $failed = @()
  $skipped = @()

  foreach ($SOFTWARE in $SOFTWARE_NAMES) {
    try {
      scoop install $SOFTWARE
      if ($LASTEXITCODE -ne 0) {
        throw "scoop install exited with code $LASTEXITCODE"
      }
      $installed += $SOFTWARE
      Write-Host "Installed: $SOFTWARE" -ForegroundColor Green
    }
    catch {
      $failed += $SOFTWARE
      Write-Warning "Failed to install ${SOFTWARE}: $_"
    }
  }

  Write-Host "`nInstallation summary:" -ForegroundColor Cyan
  Write-Host "  Installed: $($installed.Count)" -ForegroundColor Green
  Write-Host "  Skipped:   $($skipped.Count)" -ForegroundColor Yellow
  Write-Host "  Failed:    $($failed.Count)" -ForegroundColor Red
  if ($failed.Count -gt 0) {
    Write-Host "  Failed apps: $($failed -join ', ')" -ForegroundColor Red
  }

  # Your original gsudo commands for system configuration.
  Write-Host "Configuring system settings..."

  Write-Host "Temporarily disabling UAC..."
  gsudo reg add HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System /v ConsentPromptBehaviorAdmin /t REG_DWORD /d 0 /f

  try {
    Write-Host "Enabling Long Paths support..."
    gsudo Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\FileSystem' -Name 'LongPathsEnabled' -Value 1

    Write-Host "Enabling Developer Mode..."
    gsudo Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\AppModelUnlock' -Name 'AllowDevelopmentWithoutDevLicense' -Value 1

    Write-Host "Ensuring Git SSL verification is enabled..."
    git config --global http.sslverify true
  }
  finally {
    Write-Host "Restoring UAC to default settings..."
    gsudo reg add HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System /v ConsentPromptBehaviorAdmin /t REG_DWORD /d 5 /f
    gsudo reg add HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System /v PromptOnSecureDesktop /t REG_DWORD /d 1 /f
  }

  Write-Host "System configuration complete."
}

Install-Software
