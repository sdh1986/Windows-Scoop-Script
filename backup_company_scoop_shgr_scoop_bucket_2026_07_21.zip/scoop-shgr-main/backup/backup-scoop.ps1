# Backup all software installed by scoop.
function Backup-Scoop {
  try {
    $BACKUP_SCOOP = "$PSScriptRoot\scoop-backup.ps1"
    & ${BACKUP_SCOOP}
    & ${BACKUP_SCOOP} -Compress
    Write-Host 'Backup Scoop Completed Successfully.' -ForegroundColor Green -BackgroundColor Black
  }
  catch {
    Write-Error "An Error Occurred While Backup Scoop: $($_.Exception.Message)"
  }
}

Backup-Scoop
